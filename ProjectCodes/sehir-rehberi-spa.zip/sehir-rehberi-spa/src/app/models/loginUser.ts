export class LoginUser {
    userName:string;
    password:string;
}
